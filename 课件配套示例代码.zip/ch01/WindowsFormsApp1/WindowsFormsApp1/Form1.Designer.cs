﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      this.btnGreeting = new System.Windows.Forms.Button();
      this.greetingLabel = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // btnGreeting
      // 
      this.btnGreeting.Location = new System.Drawing.Point(196, 129);
      this.btnGreeting.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnGreeting.Name = "btnGreeting";
      this.btnGreeting.Size = new System.Drawing.Size(100, 29);
      this.btnGreeting.TabIndex = 0;
      this.btnGreeting.Text = "button1";
      this.btnGreeting.UseVisualStyleBackColor = true;
      this.btnGreeting.Click += new System.EventHandler(this.button1_Click);
      // 
      // greetingLabel
      // 
      this.greetingLabel.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
      this.greetingLabel.AutoSize = true;
      this.greetingLabel.Location = new System.Drawing.Point(211, 91);
      this.greetingLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.greetingLabel.Name = "greetingLabel";
      this.greetingLabel.Size = new System.Drawing.Size(0, 15);
      this.greetingLabel.TabIndex = 1;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1067, 562);
      this.Controls.Add(this.greetingLabel);
      this.Controls.Add(this.btnGreeting);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "Form1";
      this.Text = "form1";
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGreeting;
        private System.Windows.Forms.Label greetingLabel;
    }
}

