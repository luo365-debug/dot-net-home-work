﻿namespace MenuTest
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.mainMenu = new System.Windows.Forms.MenuStrip();
      this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
      this.NewFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.OpenFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.SaveFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.FontMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.ColorMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.AboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.contextMenu1 = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.重命名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.复制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.colorDialog1 = new System.Windows.Forms.ColorDialog();
      this.fontDialog1 = new System.Windows.Forms.FontDialog();
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.statusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.btnNew = new System.Windows.Forms.ToolStripButton();
      this.btnOpen = new System.Windows.Forms.ToolStripButton();
      this.btnSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.panel1 = new System.Windows.Forms.Panel();
      this.richTextBox1 = new System.Windows.Forms.RichTextBox();
      this.mainMenu.SuspendLayout();
      this.contextMenu1.SuspendLayout();
      this.statusStrip1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // mainMenu
      // 
      this.mainMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.设置ToolStripMenuItem,
            this.AboutMenuItem});
      this.mainMenu.Location = new System.Drawing.Point(0, 0);
      this.mainMenu.Name = "mainMenu";
      this.mainMenu.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
      this.mainMenu.Size = new System.Drawing.Size(1067, 28);
      this.mainMenu.TabIndex = 0;
      this.mainMenu.Text = "menuStrip1";
      // 
      // toolStripMenuItem1
      // 
      this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewFileMenuItem,
            this.OpenFileMenuItem,
            this.SaveFileMenuItem,
            this.ExitToolStripMenuItem});
      this.toolStripMenuItem1.Name = "toolStripMenuItem1";
      this.toolStripMenuItem1.Size = new System.Drawing.Size(51, 24);
      this.toolStripMenuItem1.Text = "文件";
      // 
      // NewFileMenuItem
      // 
      this.NewFileMenuItem.Name = "NewFileMenuItem";
      this.NewFileMenuItem.Size = new System.Drawing.Size(216, 26);
      this.NewFileMenuItem.Text = "新建";
      this.NewFileMenuItem.Click += new System.EventHandler(this.NewFileMenuItem_Click);
      // 
      // OpenFileMenuItem
      // 
      this.OpenFileMenuItem.Name = "OpenFileMenuItem";
      this.OpenFileMenuItem.Size = new System.Drawing.Size(216, 26);
      this.OpenFileMenuItem.Text = "打开";
      this.OpenFileMenuItem.Click += new System.EventHandler(this.OpenFileMenuItem_Click);
      // 
      // SaveFileMenuItem
      // 
      this.SaveFileMenuItem.Name = "SaveFileMenuItem";
      this.SaveFileMenuItem.Size = new System.Drawing.Size(216, 26);
      this.SaveFileMenuItem.Text = "保存";
      this.SaveFileMenuItem.Click += new System.EventHandler(this.SaveFileMenuItem_Click);
      // 
      // ExitToolStripMenuItem
      // 
      this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
      this.ExitToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
      this.ExitToolStripMenuItem.Text = "退出";
      this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click_1);
      // 
      // 设置ToolStripMenuItem
      // 
      this.设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FontMenuItem,
            this.ColorMenuItem});
      this.设置ToolStripMenuItem.Name = "设置ToolStripMenuItem";
      this.设置ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
      this.设置ToolStripMenuItem.Text = "设置";
      // 
      // FontMenuItem
      // 
      this.FontMenuItem.Name = "FontMenuItem";
      this.FontMenuItem.Size = new System.Drawing.Size(114, 26);
      this.FontMenuItem.Text = "字体";
      this.FontMenuItem.Click += new System.EventHandler(this.FontMenuItem_Click);
      // 
      // ColorMenuItem
      // 
      this.ColorMenuItem.Name = "ColorMenuItem";
      this.ColorMenuItem.Size = new System.Drawing.Size(114, 26);
      this.ColorMenuItem.Text = "颜色";
      this.ColorMenuItem.Click += new System.EventHandler(this.ColorMenuItem_Click);
      // 
      // AboutMenuItem
      // 
      this.AboutMenuItem.Name = "AboutMenuItem";
      this.AboutMenuItem.Size = new System.Drawing.Size(51, 24);
      this.AboutMenuItem.Text = "关于";
      this.AboutMenuItem.Click += new System.EventHandler(this.AboutMenuItem_Click);
      // 
      // contextMenu1
      // 
      this.contextMenu1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.contextMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.重命名ToolStripMenuItem,
            this.删除ToolStripMenuItem,
            this.复制ToolStripMenuItem});
      this.contextMenu1.Name = "contextMenuStrip1";
      this.contextMenu1.Size = new System.Drawing.Size(124, 76);
      // 
      // 重命名ToolStripMenuItem
      // 
      this.重命名ToolStripMenuItem.Name = "重命名ToolStripMenuItem";
      this.重命名ToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
      this.重命名ToolStripMenuItem.Text = "重命名";
      // 
      // 删除ToolStripMenuItem
      // 
      this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
      this.删除ToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
      this.删除ToolStripMenuItem.Text = "删除";
      // 
      // 复制ToolStripMenuItem
      // 
      this.复制ToolStripMenuItem.Name = "复制ToolStripMenuItem";
      this.复制ToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
      this.复制ToolStripMenuItem.Text = "复制";
      // 
      // statusStrip1
      // 
      this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel1,
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1});
      this.statusStrip1.Location = new System.Drawing.Point(0, 536);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
      this.statusStrip1.Size = new System.Drawing.Size(1067, 26);
      this.statusStrip1.TabIndex = 2;
      // 
      // statusLabel1
      // 
      this.statusLabel1.Name = "statusLabel1";
      this.statusLabel1.Size = new System.Drawing.Size(0, 21);
      // 
      // toolStripStatusLabel1
      // 
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new System.Drawing.Size(167, 21);
      this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
      // 
      // toolStripProgressBar1
      // 
      this.toolStripProgressBar1.Name = "toolStripProgressBar1";
      this.toolStripProgressBar1.Size = new System.Drawing.Size(133, 20);
      // 
      // openFileDialog1
      // 
      this.openFileDialog1.FileName = "openFileDialog1";
      this.openFileDialog1.Filter = "richtext files (*.rtf)|*.rtf|Text files (*.txt)|*.txt|All files (*.*)|*.*";
      // 
      // saveFileDialog1
      // 
      this.saveFileDialog1.Filter = "richtext files (*.rtf)|*.rtf|Text files (*.txt)|*.txt|All files (*.*)|*.*";
      // 
      // toolStrip1
      // 
      this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNew,
            this.btnOpen,
            this.btnSave,
            this.toolStripSeparator1});
      this.toolStrip1.Location = new System.Drawing.Point(0, 28);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1067, 27);
      this.toolStrip1.TabIndex = 4;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // btnNew
      // 
      this.btnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
      this.btnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnNew.Name = "btnNew";
      this.btnNew.Size = new System.Drawing.Size(24, 24);
      this.btnNew.Text = "新建";
      this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
      // 
      // btnOpen
      // 
      this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
      this.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnOpen.Name = "btnOpen";
      this.btnOpen.Size = new System.Drawing.Size(24, 24);
      this.btnOpen.Text = "打开";
      this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
      // 
      // btnSave
      // 
      this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
      this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new System.Drawing.Size(24, 24);
      this.btnSave.Text = "保存";
      this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.richTextBox1);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel1.Location = new System.Drawing.Point(0, 55);
      this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.panel1.Name = "panel1";
      this.panel1.Padding = new System.Windows.Forms.Padding(7, 6, 7, 6);
      this.panel1.Size = new System.Drawing.Size(1067, 481);
      this.panel1.TabIndex = 5;
      // 
      // richTextBox1
      // 
      this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.richTextBox1.ContextMenuStrip = this.contextMenu1;
      this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.richTextBox1.Location = new System.Drawing.Point(7, 6);
      this.richTextBox1.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
      this.richTextBox1.Name = "richTextBox1";
      this.richTextBox1.Size = new System.Drawing.Size(1053, 469);
      this.richTextBox1.TabIndex = 2;
      this.richTextBox1.Text = "";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1067, 562);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.statusStrip1);
      this.Controls.Add(this.mainMenu);
      this.MainMenuStrip = this.mainMenu;
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "Form1";
      this.Text = "Form1";
      this.mainMenu.ResumeLayout(false);
      this.mainMenu.PerformLayout();
      this.contextMenu1.ResumeLayout(false);
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem NewFileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenFileMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenu1;
        private System.Windows.Forms.ToolStripMenuItem 重命名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 复制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FontMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveFileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ColorMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ToolStripButton btnNew;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel1;
        private System.Windows.Forms.ToolStripMenuItem AboutMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
  }
}

