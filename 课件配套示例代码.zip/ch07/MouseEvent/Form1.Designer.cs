﻿namespace MouseEvent
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      this.label1 = new System.Windows.Forms.Label();
      this.lblPosition = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.lblEvent = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.label1.Location = new System.Drawing.Point(297, 22);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(148, 30);
      this.label1.TabIndex = 0;
      this.label1.Text = "鼠标位置:";
      // 
      // lblPosition
      // 
      this.lblPosition.AutoSize = true;
      this.lblPosition.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.lblPosition.Location = new System.Drawing.Point(451, 22);
      this.lblPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblPosition.Name = "lblPosition";
      this.lblPosition.Size = new System.Drawing.Size(88, 30);
      this.lblPosition.TabIndex = 1;
      this.lblPosition.Text = "(0,0)";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.label2.Location = new System.Drawing.Point(297, 76);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(103, 30);
      this.label2.TabIndex = 2;
      this.label2.Text = "备注：";
      // 
      // lblEvent
      // 
      this.lblEvent.AutoSize = true;
      this.lblEvent.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.lblEvent.Location = new System.Drawing.Point(396, 76);
      this.lblEvent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblEvent.Name = "lblEvent";
      this.lblEvent.Size = new System.Drawing.Size(0, 30);
      this.lblEvent.TabIndex = 3;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1067, 562);
      this.Controls.Add(this.lblEvent);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.lblPosition);
      this.Controls.Add(this.label1);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.Click += new System.EventHandler(this.Form1_Click);
      this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEvent;
    }
}

