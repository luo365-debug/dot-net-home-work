﻿namespace CommonControls
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
      this.button1 = new System.Windows.Forms.Button();
      this.checkBox1 = new System.Windows.Forms.CheckBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.radioButton2 = new System.Windows.Forms.RadioButton();
      this.radioButton1 = new System.Windows.Forms.RadioButton();
      this.panel3 = new System.Windows.Forms.Panel();
      this.radioButton3 = new System.Windows.Forms.RadioButton();
      this.radioButton4 = new System.Windows.Forms.RadioButton();
      this.label1 = new System.Windows.Forms.Label();
      this.linkLabel1 = new System.Windows.Forms.LinkLabel();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.richTextBox1 = new System.Windows.Forms.RichTextBox();
      this.flowLayoutPanel1.SuspendLayout();
      this.panel1.SuspendLayout();
      this.panel3.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // flowLayoutPanel1
      // 
      this.flowLayoutPanel1.Controls.Add(this.button1);
      this.flowLayoutPanel1.Controls.Add(this.checkBox1);
      this.flowLayoutPanel1.Controls.Add(this.panel1);
      this.flowLayoutPanel1.Controls.Add(this.panel3);
      this.flowLayoutPanel1.Controls.Add(this.label1);
      this.flowLayoutPanel1.Controls.Add(this.linkLabel1);
      this.flowLayoutPanel1.Controls.Add(this.textBox2);
      this.flowLayoutPanel1.Controls.Add(this.textBox3);
      this.flowLayoutPanel1.Controls.Add(this.comboBox1);
      this.flowLayoutPanel1.Controls.Add(this.textBox1);
      this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
      this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.flowLayoutPanel1.Name = "flowLayoutPanel1";
      this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(7, 6, 7, 6);
      this.flowLayoutPanel1.Size = new System.Drawing.Size(1067, 121);
      this.flowLayoutPanel1.TabIndex = 1;
      // 
      // button1
      // 
      this.button1.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
      this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.button1.Location = new System.Drawing.Point(11, 10);
      this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(100, 29);
      this.button1.TabIndex = 0;
      this.button1.Text = "保存";
      this.button1.UseVisualStyleBackColor = true;
      // 
      // checkBox1
      // 
      this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.checkBox1.AutoSize = true;
      this.checkBox1.Location = new System.Drawing.Point(119, 15);
      this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.checkBox1.Name = "checkBox1";
      this.checkBox1.Size = new System.Drawing.Size(74, 19);
      this.checkBox1.TabIndex = 1;
      this.checkBox1.Text = "复选框";
      this.checkBox1.UseVisualStyleBackColor = true;
      // 
      // panel1
      // 
      this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.panel1.Controls.Add(this.radioButton2);
      this.panel1.Controls.Add(this.radioButton1);
      this.panel1.Location = new System.Drawing.Point(201, 10);
      this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(131, 29);
      this.panel1.TabIndex = 2;
      // 
      // radioButton2
      // 
      this.radioButton2.AutoSize = true;
      this.radioButton2.Location = new System.Drawing.Point(60, 5);
      this.radioButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton2.Name = "radioButton2";
      this.radioButton2.Size = new System.Drawing.Size(43, 19);
      this.radioButton2.TabIndex = 1;
      this.radioButton2.TabStop = true;
      this.radioButton2.Text = "女";
      this.radioButton2.UseVisualStyleBackColor = true;
      // 
      // radioButton1
      // 
      this.radioButton1.AutoSize = true;
      this.radioButton1.Location = new System.Drawing.Point(5, 5);
      this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.Size = new System.Drawing.Size(43, 19);
      this.radioButton1.TabIndex = 0;
      this.radioButton1.TabStop = true;
      this.radioButton1.Text = "男";
      this.radioButton1.UseVisualStyleBackColor = true;
      // 
      // panel3
      // 
      this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.panel3.Controls.Add(this.radioButton3);
      this.panel3.Controls.Add(this.radioButton4);
      this.panel3.Location = new System.Drawing.Point(340, 10);
      this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(131, 29);
      this.panel3.TabIndex = 9;
      // 
      // radioButton3
      // 
      this.radioButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.radioButton3.AutoSize = true;
      this.radioButton3.Location = new System.Drawing.Point(60, 5);
      this.radioButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton3.Name = "radioButton3";
      this.radioButton3.Size = new System.Drawing.Size(58, 19);
      this.radioButton3.TabIndex = 1;
      this.radioButton3.TabStop = true;
      this.radioButton3.Text = "女士";
      this.radioButton3.UseVisualStyleBackColor = true;
      // 
      // radioButton4
      // 
      this.radioButton4.AutoSize = true;
      this.radioButton4.Location = new System.Drawing.Point(5, 4);
      this.radioButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton4.Name = "radioButton4";
      this.radioButton4.Size = new System.Drawing.Size(58, 19);
      this.radioButton4.TabIndex = 0;
      this.radioButton4.TabStop = true;
      this.radioButton4.Text = "先生";
      this.radioButton4.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(479, 17);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(37, 15);
      this.label1.TabIndex = 3;
      this.label1.Text = "标签";
      // 
      // linkLabel1
      // 
      this.linkLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.linkLabel1.AutoSize = true;
      this.linkLabel1.Location = new System.Drawing.Point(524, 17);
      this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.linkLabel1.Name = "linkLabel1";
      this.linkLabel1.Size = new System.Drawing.Size(67, 15);
      this.linkLabel1.TabIndex = 5;
      this.linkLabel1.TabStop = true;
      this.linkLabel1.Text = "链接标签";
      // 
      // textBox2
      // 
      this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.textBox2.Location = new System.Drawing.Point(599, 12);
      this.textBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(132, 25);
      this.textBox2.TabIndex = 6;
      this.textBox2.Text = "单行文本框";
      this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
      // 
      // textBox3
      // 
      this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.textBox3.Location = new System.Drawing.Point(739, 12);
      this.textBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.textBox3.Name = "textBox3";
      this.textBox3.PasswordChar = '*';
      this.textBox3.Size = new System.Drawing.Size(132, 25);
      this.textBox3.TabIndex = 7;
      // 
      // comboBox1
      // 
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Location = new System.Drawing.Point(879, 10);
      this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(160, 23);
      this.comboBox1.TabIndex = 8;
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(11, 47);
      this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.textBox1.Size = new System.Drawing.Size(280, 62);
      this.textBox1.TabIndex = 4;
      this.textBox1.Text = "多行文本框 \r\n第二行";
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.richTextBox1);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(0, 121);
      this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.panel2.Name = "panel2";
      this.panel2.Padding = new System.Windows.Forms.Padding(7, 6, 7, 6);
      this.panel2.Size = new System.Drawing.Size(1067, 441);
      this.panel2.TabIndex = 2;
      // 
      // richTextBox1
      // 
      this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.richTextBox1.Location = new System.Drawing.Point(7, 6);
      this.richTextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.richTextBox1.Name = "richTextBox1";
      this.richTextBox1.Size = new System.Drawing.Size(1053, 429);
      this.richTextBox1.TabIndex = 3;
      this.richTextBox1.Text = "富文本框";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1067, 562);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.flowLayoutPanel1);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.flowLayoutPanel1.ResumeLayout(false);
      this.flowLayoutPanel1.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.panel3.ResumeLayout(false);
      this.panel3.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.RadioButton radioButton3;
    private System.Windows.Forms.RadioButton radioButton4;
  }
}

