﻿namespace CheckedListBox
{
    partial class Form1
    {
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
      this.SuspendLayout();
      // 
      // checkedListBox1
      // 
      this.checkedListBox1.Items.AddRange(new object[] {
            "Windows",
            "OS/2",
            "Unix",
            "Linux",
            "Macintosh"});
      this.checkedListBox1.Location = new System.Drawing.Point(117, 51);
      this.checkedListBox1.Name = "checkedListBox1";
      this.checkedListBox1.Size = new System.Drawing.Size(182, 144);
      this.checkedListBox1.TabIndex = 0;
      this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 18);
      this.ClientSize = new System.Drawing.Size(336, 221);
      this.Controls.Add(this.checkedListBox1);
      this.Name = "Form1";
      this.Text = "Form1";
      this.ResumeLayout(false);

        }

        #endregion
    }
}

