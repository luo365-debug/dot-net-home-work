﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Serialize {

  public class Program {
    [Serializable]
    public class Person {
      public int Age { get; set; }
      public string Name { get; set; }
      public Person() { }
      public Person(string name, int age) {
        Age = age;
        Name = name;
      }

      public override string ToString() {
        return "Name:" + Name + ", Age:" + Age;
      }
    }
    static void Main(string[] args) {
      Person[] persons = { new Person("zhang", 23), new Person("wang", 22) };
      Console.WriteLine("original array object:");
      Array.ForEach(persons, p => Console.WriteLine(p.ToString()));


      //二进制的序列化
      //Console.WriteLine("serialized int s.temp.");
      //BinaryFormatter binaryFormatter = new BinaryFormatter();
      //using(FileStream fs = new FileStream("s.temp", FileMode.Create))
      //{
      //    binaryFormatter.Serialize(fs, persons);
      //}

      //using(FileStream fs = new FileStream("s.temp", FileMode.Open))
      //{
      //    Person[] persons2 = (Person[])binaryFormatter.Deserialize(fs);
      //    Console.WriteLine("Deserialized from s.temp");
      //    Array.ForEach(persons2,p=>Console.WriteLine(p));
      //}

      //xml序列化
      XmlSerializer xmlSerializer = new XmlSerializer(typeof(Person[]));
      using (FileStream fs = new FileStream("s.xml", FileMode.Create)) {
        xmlSerializer.Serialize(fs, persons);
      }
      Console.WriteLine("\n Serialized as XML");
      Console.WriteLine(File.ReadAllText("s.xml"));

      using (FileStream fs = new FileStream("s.xml", FileMode.Open)) {
        Person[] persons3 = (Person[])xmlSerializer.Deserialize(fs);
        Console.WriteLine("\n Deserialized from s.xml");
        Array.ForEach(persons3, p => Console.WriteLine(p));
      }


    }
  }
}
