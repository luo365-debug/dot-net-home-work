﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public class MultiClass
    {
        public static long Multi(long x,long y) {
            return x * y;
        }
    }
}
