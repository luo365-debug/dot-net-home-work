﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public class AddClass
    {
        public static long Add(long i,long j) {
            return i + j;
        }
    }
}
